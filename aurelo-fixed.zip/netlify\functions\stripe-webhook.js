const stripe = require('stripe')('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');

exports.handler = async (event, context) => {
  const sig = event.headers['stripe-signature'];
  const webhookSecret = 'whsec_rcZH0PhLmMHhKwajOvphYy5tj2LSkUAY';

  let stripeEvent;

  try {
    stripeEvent = stripe.webhooks.constructEvent(event.body, sig, webhookSecret);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Webhook signature verification failed' })
    };
  }

  // Обработка различных событий
  switch (stripeEvent.type) {
    case 'checkout.session.completed':
      const session = stripeEvent.data.object;
      console.log('Checkout session completed:', session.id);
      
      // Здесь можно добавить логику для обновления пользователя в Firebase
      // Например, активировать подписку пользователя
      break;

    case 'customer.subscription.created':
      const subscription = stripeEvent.data.object;
      console.log('Subscription created:', subscription.id);
      
      // Обновить статус подписки в Firebase
      break;

    case 'customer.subscription.updated':
      const updatedSubscription = stripeEvent.data.object;
      console.log('Subscription updated:', updatedSubscription.id);
      
      // Обновить данные подписки в Firebase
      break;

    case 'customer.subscription.deleted':
      const deletedSubscription = stripeEvent.data.object;
      console.log('Subscription deleted:', deletedSubscription.id);
      
      // Отключить подписку в Firebase
      break;

    case 'invoice.payment_succeeded':
      const invoice = stripeEvent.data.object;
      console.log('Payment succeeded:', invoice.id);
      
      // Обновить статус платежа
      break;

    case 'invoice.payment_failed':
      const failedInvoice = stripeEvent.data.object;
      console.log('Payment failed:', failedInvoice.id);
      
      // Обработать неудачный платеж
      break;

    default:
      console.log(`Unhandled event type: ${stripeEvent.type}`);
  }

  return {
    statusCode: 200,
    body: JSON.stringify({ received: true })
  };
};
