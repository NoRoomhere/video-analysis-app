const stripe = require('stripe')('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');

exports.handler = async (event, context) => {
  // Включаем CORS
  const headers = {
    'Access-Control-Allow-Origin': 'https://aurelo.dev',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  };

  // Обработка preflight запросов
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  try {
    const { priceId, customerEmail, successUrl, cancelUrl, planId, trialDays } = JSON.parse(event.body);

    // Создаем или находим клиента
    let customer;
    const existingCustomers = await stripe.customers.list({
      email: customerEmail,
      limit: 1
    });

    if (existingCustomers.data.length > 0) {
      customer = existingCustomers.data[0];
    } else {
      customer = await stripe.customers.create({
        email: customerEmail,
        metadata: {
          planId: planId
        }
      });
    }

    // Создаем Checkout Session
    const session = await stripe.checkout.sessions.create({
      customer: customer.id,
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: {
        planId: planId,
        customerEmail: customerEmail
      },
      subscription_data: trialDays ? {
        trial_period_days: trialDays
      } : undefined,
      allow_promotion_codes: true,
      billing_address_collection: 'required',
      customer_update: {
        address: 'auto',
        name: 'auto'
      }
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        sessionId: session.id
      })
    };

  } catch (error) {
    console.error('Error creating checkout session:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Failed to create checkout session'
      })
    };
  }
};
