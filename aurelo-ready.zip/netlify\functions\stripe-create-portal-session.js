const stripe = require('stripe')('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');

exports.handler = async (event, context) => {
  // Включаем CORS
  const headers = {
    'Access-Control-Allow-Origin': 'https://aurelo.dev',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  };

  // Обработка preflight запросов
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  try {
    const { customerId, returnUrl } = JSON.parse(event.body);

    // Создаем Customer Portal Session
    const session = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: returnUrl,
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        url: session.url
      })
    };

  } catch (error) {
    console.error('Error creating portal session:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Failed to create portal session'
      })
    };
  }
};
